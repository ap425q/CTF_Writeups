#include <stdlib.h>
int main() {
    system("cat flag.txt");
}
