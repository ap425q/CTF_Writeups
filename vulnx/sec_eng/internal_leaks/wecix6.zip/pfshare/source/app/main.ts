import BaseClass from "./base.js"
import pfShareClient from "../libs/pfshare_client.js";
import { AxiosError } from "axios";

export default class HTB {
    private BaseClass: BaseClass;

    constructor(token?: string) {
        this.BaseClass = new BaseClass()
		this.BaseClass.setAccessToken(token ?? '')
	}

    public init = async (username: string, password: string): Promise<IPFShareLoginResponse> => {
		const login_response = await this.BaseClass.login(
			username,
			password
		)
		return login_response
    }

	public fetchWhoAmI = async () : Promise<IPFShareWhoamiResponse> => {
		try {
			const { data } = await pfShareClient(this.BaseClass.accessCreds())
				.get("/me")

			return data
		}
		catch(err) {
			if(err instanceof AxiosError) {
				throw new Error(err.response?.data.message ?? err.message)
			}
			else
				throw new Error("Unknown error")
		}
	}

    public fetchMyFiles = async () : Promise<IPFShareMyFilesResponse> => {
		try {
			const { data } = await pfShareClient(this.BaseClass.accessCreds())
                .get("/uploads")

            return data
		}
		catch (err) {
			if(err instanceof AxiosError) {
                throw new Error(err.response?.data.message ?? err.message)
            }
            else
                throw new Error("Unknown error")
		}
	}

	public fetchFile = async (fileId: string) : Promise<IPFShareMyFileResponse> => {
		try {
			const { data } = await pfShareClient(this.BaseClass.accessCreds())
				.get(`/upload/${fileId}`)

			return data
		}
		catch (err) {
			if(err instanceof AxiosError) {
				throw new Error(err.response?.data.message ?? err.message)
			}
			else
				throw new Error("Unknown error")
		}
	}

	public fetchAllFiles = async () : Promise<IPFShareMyFilesResponse> => {
		try {
			const { data } = await pfShareClient(this.BaseClass.accessCreds())
                .get("/uploads/all")

            return data
		}
		catch (err) {
			if(err instanceof AxiosError) {
                throw new Error(err.response?.data.message ?? err.message)
            }
            else
                throw new Error("Unknown error")
		}
	}

	public downloadFile = async (fileId: string) : Promise<any> => {
		try {
			const { data } = await pfShareClient(this.BaseClass.accessCreds())
				.get(`/upload/${fileId}/download`)

			return data
		}
		catch (err) {
			if(err instanceof AxiosError) {
				throw new Error(err.response?.data.message ?? err.message)
			}
			else
				throw new Error("Unknown error")
		}
	}
}
