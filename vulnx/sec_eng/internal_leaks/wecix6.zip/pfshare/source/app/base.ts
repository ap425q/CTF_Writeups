import { AxiosError } from "axios";
import pfClient from "../libs/pfshare_client.js";

export default class BaseClass {
    private access_token: string;

	constructor(token?: string) {
		this.access_token = token ?? '';
	}

    public login = async (username: string, password: string): Promise<IPFShareLoginResponse> => {
		try {
			const login_response = await this.getAccessToken(username, password);
			this.access_token = login_response.token;
			return login_response
		}
		catch(err) {
			if(err instanceof AxiosError) {
				throw new Error(err.message)
			}
			else {
				throw new Error("Unknown error")
			}
		}
	}

    public accessCreds = () => {
        return this.access_token
    }

    public getAccessToken = async (email: string, password: string): Promise<IPFShareLoginResponse> => {
		return new Promise(async function(resolve, reject) {
			try {
                const { data } = await pfClient()
                    .post("/login", {
                        email,
                        password,
                    });
                resolve(data);
            } catch (err: any) {
                reject(err);
            }
		})
	}

	public setAccessToken = (token: string) => {
		this.access_token = token;
	}
}
