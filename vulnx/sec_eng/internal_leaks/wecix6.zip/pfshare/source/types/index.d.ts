interface IPFShareLoginResponse {
	data: string;
	token: string;
	error?: string;
}

interface IPFShareUploadResponse {
	data: string;
	error?: string;
}

interface IPFShareWhoamiResponse {
	id: string;
    name: string;
    role: string;
    email: string;
    created_at: string;
	error?: string;
}

interface IPFShareMyFilesResponse {
	data: IPFShareMyFileResponse[]
	error?: string;
}

interface IPFShareMyFileResponse {
	id: number;
	user_id: number;
	file_name: string;
	file_path: string;
	created_at: Date;
	updated_at: Date;
	error?: string;
}