import Conf from 'conf';

export const store = new Conf({
	projectName: 'pfshare-cli',
	projectVersion: '0.0.0',
});
