import axios from 'axios';

const pfSClient = (token?: string) => {
    return axios.create({
        baseURL: 'https://share.comefindme.dev',
        timeout: 10000,
        headers: {
            'Content-Type': 'application/json',
            'User-Agent': 'pfShare',
            'Authorization': 'Bearer ' + token,
        }
    })
}

export default pfSClient;
