import React, {useState, useEffect} from 'react';
import { Text } from 'ink';
import zod from 'zod';

import PFShare from '../app/main.js';
import { store } from '../libs/config.js';

export const options = zod.object({
	email: zod.string().describe('Email'),
	password: zod.string().describe('Password'),
});

type Props = {
	options: zod.infer<typeof options>;
};

const Auth = ({options}: Props) => {
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState('');
	const email = options.email;
	const password = options.password;

	store.set('email', email);
	store.set('password', password);

	const pfShareUser = new PFShare();

	useEffect(() => {
		pfShareUser.init(
			email,
			password,
		).then((token) => {
			if(token.error) {
				setError(token.error);
				setLoading(false);
			}
			else {
                store.set('token', token.token);
                setLoading(false);
            }
		})
	}, []);

	if(loading) {
		return (
			<Text>
				<Text color="cyan"> Login in-progress .. </Text>
			</Text>
		);
	}

	else if (error) {
		return (
			<Text>
				<Text color="red"> {error} </Text>
			</Text>
		);
	}

	else {
		return (
			<Text>
				<Text color="green"> Login success !! </Text>
			</Text>
		);
	}
}

export default Auth;
