import React from 'react';
import { Text } from 'ink';

export default function Index() {
	return (
		<Text>
			<Text color="green">pfShare</Text> CLI {"\n\n"}
			Run with <Text color="cyan"> --help </Text> to view helpl {"\n"}
		</Text>
	);
}
