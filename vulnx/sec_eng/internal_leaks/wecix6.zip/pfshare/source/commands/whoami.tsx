import React, { useEffect, useState } from 'react';
import { Text } from 'ink';

import IPFShare from '../app/main.js';
import { store } from '../libs/config.js';

const Whoami = () => {
	const [user, setUser] = useState<IPFShareWhoamiResponse>();
	const [loading, setLoading] = useState(true);
	const token = store.get('token') as string;

	
	const ipfshareUser = new IPFShare(token);
	
	useEffect(() => {
		ipfshareUser.fetchWhoAmI().then((user) => {
			setUser(user);
			setLoading(false);
		}).catch(() => {
			setLoading(false);
		});
	}, []);
	
	if(!token) {
		return (
			<Text color={'red'}>
				You are not logged in. Please login first.
			</Text>
		);
	}
	
	if(loading) {
		return (
			<Text>
				<Text color="cyan"> Loading ... </Text>
			</Text>
		);
	}
	else if(user) {
		return (
			<Text>
				ID : <Text color="green" italic> {user.id} </Text>
				{"\n"}
				Role : <Text color="green" italic> {user.role} </Text>
				{"\n"}
				Name : <Text color="green" italic> {user.name} </Text>
				{"\n"}
				Email : <Text color="green" italic> {user.email} </Text>
				{"\n"}
				Created at : <Text color="green" italic> {user.created_at} </Text>
			</Text>
		)
	}
	else {
		return (
			<Text>
				<Text color="red"> Are you sure you logged in ? </Text>
			</Text>
		)
	}
}

export default Whoami;
