import React, { useEffect, useState } from 'react';
import { Text } from 'ink';
import zod from 'zod';
import fs from 'fs';

import PFShare from '../../app/main.js';
import { store } from '../../libs/config.js';

export const options = zod.object({
	fileid: zod.string().describe('File ID'),
	output: zod.string().describe('Output file name'),
});

type Props = {
	options: zod.infer<typeof options>;
};

const Download = (
	{options}: Props
) => {
	const [fileData, setFileData] = useState<any>();
	const [error, setError] = useState('');
	const [loading, setLoading] = useState(true);
	const token = store.get('token') as string;
	
	const pfShareUser = new PFShare(token);
	
	useEffect(() => {
		pfShareUser.downloadFile(
			options.fileid
		).then((file) => {
			if(file.error) {
                setError(file.error);
            }
			else
				setFileData(file);
			setLoading(false);
		}).catch(() => {
			setLoading(false);
		});
	}, []);
	
	if(!token) {
		return (
			<Text color={'red'}>
				You are not logged in. Please login first.
			</Text>
		);
	}
	
	if(loading) {
		return (
			<Text>
				<Text color="cyan"> Loading ... </Text>
			</Text>
		);
	}
	
	else if(error) {
		return (
			<Text>
				<Text color="red"> {error} </Text>
			</Text>
		);
	}

	else if(fileData) {
		fs.writeFile(options.output, JSON.stringify(fileData), (err) => {
			if (err) throw err;
		})
		
		return (
			<Text>
				<Text color="green"> File downloaded successfully !! </Text>
			</Text>
		)
	}

	else {
		return (
			<Text>
				<Text color="red"> Are you sure you logged in ? </Text>
			</Text>
		)
	}
}

export default Download;
