import zod from 'zod';
import React, { useEffect, useState } from 'react';
import { Text } from 'ink';

import PFShare from '../../app/main.js';
import { store } from '../../libs/config.js';

export const options = zod.object({
	all: zod.boolean().describe('Admin: List files of all users').default(false),
});

type Props = {
	options: zod.infer<typeof options>;
};

const List = (
	{options}: Props
) => {
	const [error, setError] = useState('');
	const [fileList, setFileList] = useState<IPFShareMyFileResponse[]>();
	const [loading, setLoading] = useState(true);
	const token = store.get('token') as string;

	
	const pfShareUser = new PFShare(token);
	
	useEffect(() => {
		if(options.all){
			pfShareUser.fetchAllFiles().then((files) => {
				if(files.error) {
                    setError(files.error);
                }
				else 
					setFileList(files.data);
				setLoading(false);
			}).catch(() => {
				setLoading(false);
			});
		}
		else {
			pfShareUser.fetchMyFiles().then((files) => {
				if(files.error) {
                    setError(files.error);
                }
				else 
					setFileList(files.data);
				setLoading(false);
			}).catch(() => {
				setLoading(false);
			});
		}
	}, []);
	
	if(!token) {
		return (
			<Text color={'red'}>
				You are not logged in. Please login first.
			</Text>
		);
	}
	
	if(loading) {
		return (
			<Text>
				<Text color="cyan"> Loading ... </Text>
			</Text>
		);
	}

	else if(error){
		return (
			<Text>
				<Text color="red"> {error} </Text>
			</Text>
		);
	}

	else if(fileList) {
		return (
			<Text>
				{fileList.map((file) => (
					<Text key={file.id}>
						{"\n"}
						ID : <Text color="green" italic> {file.id} </Text>
						{"\n"}
						Name : <Text color="green" italic> {file.file_name} </Text>
						{"\n"}
						Created at : <Text color="green" italic> {file.created_at.toString()} </Text>
						{"\n"}
						----------------------------------
					</Text>
				))}
			</Text>
		)
	}
	else {
		return (
			<Text>
				<Text color="red"> Are you sure you logged in ? </Text>
			</Text>
		)
	}
}

export default List;
