import zod from 'zod';
import React, { useEffect, useState } from 'react';
import { Text } from 'ink';

import PFShare from '../../app/main.js';
import { store } from '../../libs/config.js';

export const options = zod.object({
	fileid: zod.string().describe('File ID'),
});

type Props = {
	options: zod.infer<typeof options>;
};

const Get = (
	{options}: Props
) => {
	const [fileList, setFileList] = useState<IPFShareMyFileResponse>();
	const [error, setError] = useState('');
	const [loading, setLoading] = useState(true);
	const token = store.get('token') as string;

	
	const pfShareUser = new PFShare(token);
	
	useEffect(() => {
		pfShareUser.fetchFile(
			options.fileid
		).then((file) => {
			if(file.error) {
				setError(file.error);
			}
			else
				setFileList(file);
			setLoading(false);
		}).catch(() => {
			setLoading(false);
		});
	}, []);
	
	if(!token) {
		return (
			<Text color={'red'}>
				You are not logged in. Please login first.
			</Text>
		);
	}
	
	if(loading) {
		return (
			<Text>
				<Text color="cyan"> Loading ... </Text>
			</Text>
		);
	}

	else if(error) {
		return (
			<Text>
				<Text color="red"> {error} </Text>
			</Text>
		);
	}

	else if(fileList) {
		return (
			<Text>
				{"\n"}
				ID : <Text color="green" italic> {fileList.id} </Text>
				{"\n"}
				Name : <Text color="green" italic> {fileList.file_name} </Text>
				{"\n"}
				FilePath : <Text color="green" italic> {fileList.file_path} </Text>
				{"\n"}
				UserID : <Text color="green" italic> {fileList.user_id} </Text>
				{"\n"}				
				Created at : <Text color="green" italic> {fileList.created_at.toString()} </Text>
				{"\n"}
			</Text>
		)
	}
	else {
		return (
			<Text>
				<Text color="red"> Are you sure you logged in ? </Text>
			</Text>
		)
	}
}

export default Get;
