#!/usr/bin/env node
import Pastel from 'pastel';

const app = new Pastel({
	importMeta: import.meta,
	description: 'pfshare cli client',
	name: 'pfshare',
	version: '0.0.0-git',
});

await app.run();
